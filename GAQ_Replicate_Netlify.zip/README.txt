GAQ — Replicate face-swap integration

Included:
- index.html — GAQ site UI, with Swap Photo connected to the function endpoint
- netlify/functions/face-swap.mjs — server-side Replicate API proxy
- netlify.toml — Netlify configuration

IMPORTANT:
The current Netlify Drop/static deploy does not run serverless functions by itself. Deploy this project through a Git repository connected to Netlify, or using Netlify CLI/API with functions enabled.

After the project is deployed with functions:
1. In Netlify site settings, open Environment variables.
2. Add variable name: REPLICATE_API_TOKEN
3. Set its value to the Replicate token created by the user. Never put this token in index.html or public code.
4. Trigger a new deploy.

Only Swap Photo is wired to the Replicate face-swap model. Video swap and background removal are not connected in this version.
Replicate charges for model runs; check current account credits and model pricing before processing.
