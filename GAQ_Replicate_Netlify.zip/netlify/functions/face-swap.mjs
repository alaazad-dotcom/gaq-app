const MODEL_VERSION = "codeplugtech/face-swap:278a81e7ebb22db98bcba54de985d22cc1abeead2754eb1f2af717247be69b34";
const API = "https://api.replicate.com/v1/predictions";

export default async (request) => {
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) return json({ error: "Липсва REPLICATE_API_TOKEN в Netlify environment variables." }, 500);
  try {
    if (request.method === "POST") {
      const body = await request.json();
      if (!isSmallJpegDataUrl(body.input_image) || !isSmallJpegDataUrl(body.swap_image)) {
        return json({ error: "Снимките не са подготвени правилно. Избери отново двете снимки." }, 400);
      }
      const upstream = await fetch(API, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          version: MODEL_VERSION,
          input: { input_image: body.input_image, swap_image: body.swap_image }
        })
      });
      const data = await upstream.json();
      if (!upstream.ok) return json({ error: data.detail || data.title || "Replicate отказа заявката. Провери токена и кредитите." }, upstream.status);
      return json({ id: data.id, status: data.status }, 202);
    }
    if (request.method === "GET") {
      const id = new URL(request.url).searchParams.get("id");
      if (!id || !/^[a-zA-Z0-9_-]+$/.test(id)) return json({ error: "Липсва или е невалиден ID на обработката." }, 400);
      const upstream = await fetch(`${API}/${encodeURIComponent(id)}`, { headers: { Authorization: `Bearer ${token}` } });
      const data = await upstream.json();
      if (!upstream.ok) return json({ error: data.detail || data.title || "Неуспешна проверка на резултата." }, upstream.status);
      return json({ id: data.id, status: data.status, output: data.output, error: data.error });
    }
    return json({ error: "Използвай POST или GET." }, 405);
  } catch (error) {
    return json({ error: "Грешка при свързване с Replicate. Опитай отново." }, 500);
  }
};

function isSmallJpegDataUrl(value) {
  return typeof value === "string" && value.startsWith("data:image/jpeg;base64,") && value.length < 400000;
}
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });
}
